Action 

---



### Git Hub Action

[프로텍션 룰 적용](https://kotlinworld.com/292#GitHub%EC%-D%--%--Branch%--Protection%--Rules)

위의 방법 뿐만 아니라 Git에서 제공하는 Action을 통해 Test검증 및 배포를 할 수 있다.

다음과 같은 문법의 형식을 따른다.

```apl
name: action name # 이름

on: # 이벤트 시작
  push: # 깃에 푸시될때
    branches: [development, stage, master] # 적용시킬 repo 리스트

env: # 필요한 환경변수 선언
  ADDRESS: # some address
  CODE_DEPLOY_APP_NAME: # name of code deploy app
  TARGET_ENVIRONMENT: # logic to divide branches
	
jobs: # 실행문
  build: # 실행 ID
    name: Build, Deploy S3, EC2
    runs-on: ubuntu-18.04 # 인스턴스

    strategy: # 운영 전략
      matrix: 
        node-version: [12.16.x] # 노드 버전 선택

    steps: # CI 전략 작성
      - uses: actions/checkout@v2 # 깃헙 액션 버전 정의

      - name: Use Node.js ${{ matrix.node-version }} # 사용할 노드 버전 정의
        uses: actions/setup-node@v2
        with:
          node-version: ${{ matrix.node-version }}
          cache: 'npm'

      - name: Dependency install # 라이브러리 설치
        run: npm install
			
      - name: Build # 빌드
        run: npm run build
        
      - name: Test # 테스트 추가
				run: npm test
				
      - name: AWS 연동 설정 # AWS 연동 설정
        uses: aws-actions/configure-aws-credentials@v1
        with:
          aws-access-key-id: ${{ secrets.AWS_IAM_MANAGE_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_IAM_MANAGE_SECRET_ACCESS_KEY }}
          aws-region: ap-northeast-2

      - name: env 파일 추가 # env 파일 추가
        run: aws s3 cp s3://energyx-api/env/.env.${{env.TARGET_ENVIRONMENT}} ./

      - name: zip 생성 # 빌드 파일 압축
        run: zip -qq -r ./build.zip .
        shell: bash

      - name: 빌드 압축 파일 S3 업로드 # s3 빌드 파일 업로드
        run: aws s3 cp --region ap-northeast-2 ./build.zip s3://$ADDRESS/${{env.TARGET_ENVIRONMENT}}/build.zip

```

추가로 **[깃허브 스크립트](https://github.com/actions/github-script)**를 사용하여 테스트 구문을 구체화 해줄수 있다.

```apl
		- name: Test # 테스트 추가
           run: npm test
		 - name: Test Fail # 테스트가 실패 할 경우 액션
           uses: actions/github-script@0.2.0  # github script 액션 사용
           with:
              github-token: ${{secrets.GITHUB_TOKEN}}  # github token 사용
              script: |                        # 스크립트 작성
                const ref = "${{github.ref}}"
                const pull_number = Number(ref.split("/")[2])
                await github.pulls.createReview({
                  ...context.repo,
                  pull_number,
                  body:"테스트 코드를 다시한번 확인해주세요.",
                  event: "REQUEST_CHANGES"
                })
                await github.pulls.update({
                  ...context.repo,
                  pull_number,
                  state: "closed" # 엑션 클로즈 옵션
                })
          if: failure() # 테스트가 실패할경우 발생 옵션
```



**참고 :** [카카오 깃액션 블로그](https://fe-developers.kakaoent.com/2022/220106-github-actions/)

