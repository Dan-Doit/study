# Github Packages Registry



### 깃 허브 패키지 레지스트리

프로젝트를 진행하여 Private화 하는 작업을 진행할때가 가끔있습니다.

예를들어 사내 여러가지 프로젝트에서 공통으로 사용하는 컴포넌트를 한대 모아논 모듈이라든지

이런것들을 라이브러리화 하여 마치 NPM Private처럼 사용하면 얼마나 좋을까요?

물론 여러가지 방법이 있겠지만 여기 Git Hub에서 제공하는 좋은 방법이 있습니다.

![image-20220620083952200](Package.assets/image-20220620083952200.png)

[링크 : 깃허브 패키지 레지스트리](https://github.com/features/packages)



### 깃 액션

이미 우리는 CI/CD를 깃액션으로 만들어 본 기억이 있습니다.

우리가 흔히 배포를 하여 이를 공식화 하는것을 Publish라고 합니다.

깃허브 패키지 또한 이런 Publish 작업을 통하여 배포를 하는데요.

이 작업을 깃 액션을 통해 자동화를 진행해 볼까합니다.

먼저 우리는 프로젝트의 리포지토리와 어느 경로에서 Publish 될건지 정해주어야 합니다.

이 설정은 먼저 `package.json`파일에 적용을 합니다.

```json
  "repository": {
    "type": "git",
    "url": "git+https://github.com/Dan-Doit/Common-Component.git"
  },
  "publishConfig": {
    "registry":"https://npm.pkg.github.com"
  },
```

깃허브 주소와 특정 라이브러리를 깃허브 npm에서 내려받을 주소를 적어줍니다.



다음 깃 액션 코드입니다.

다음 코드를 볼까요?

```json
name: Common Component Package

on:
  push:
    branches: [master]

jobs:
  publish:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: 14.17.0
          registry-url: 'https://npm.pkg.github.com'
      - run: npm install
      - run: npm run build
      - run: npm publish
        env:
          NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

다음 스탭으로 Publish 시킵니다.

- npm install 로 프로젝트 내 필요한 라이브러리를 다운로드합니다.

- npm run build 를 통해 프로젝트를 빌드합니다.

  이때 빌드 될때 default로 바라보는 파일을 정해주어야합니다.

  ![스크린샷 2022-06-20 오전 8.53.34](Package.assets/스크린샷 2022-06-20 오전 8.53.34.png) 

- 다음 파일을 배포하기위해 npm으로 Publish 해줍니다.





### NPMRC

`.npmrc` 라는 파일이 있습니다.

이 파일은 root경로에 있어야 하며 npm에 관한 설정을 해줍니다.

그래서 이 파일이 무엇이냐!

바로 특정 이름으로 시작하는 라이브러리를 기존 npm package라이브러리로 부터 다운로드 되는것이 아닌

내가 원하는 경로에서 다운로드 되도록 설정을 해줄수도 있습니다.

우리는 Private한 레포지토리에서 install 하므로 깃허브 토큰을 필요로 하게됩니다.

먼저 퍼블리쉬가 정상적으로 완료가 되었다면 이런식으로 보여지게 됩니다.

![image-20220620090037891](Package.assets/image-20220620090037891.png) 

패키지를 클릭해보면 다음과같이 어떻게 설치 할수 있는지 명령어 인수가 나오게 됩니다.

![image-20220620090304565](Package.assets/image-20220620090304565.png) 

하지만 무조건 적으로 다운로드가 되지는 않습니다.

성공적으로 다운로드를 받으려면 다운로드 받을 프로젝트 root경로에 `.npmrc` 파일을 생성후 다음과같이 작성을 해줍니다.

```json
@energyx-dev:registry=https://npm.pkg.github.com/
//npm.pkg.github.com/:_authToken=발급받은토큰
```

이런식으로 하면 패키지가 성공적으로 다운로드 되는것을 확인할수 있습니다.