## CI (Continuous Integration)

### 지속적인 통합

자동으로 빌드를 진행하고 테스트를 진행한 후에 코드를 통합하는 소프트웨어 개발 방식

대표적으로 Jenkins, Circle CI, TeamCity이 있다.

---

### Circle CI 

깃허브와 쉽게 연동이 가능하며 엔터프라이즈급에서는 과금이 발생될 수도 있다.

깃허브 계정으로 Authorize GitHub를 통해 쉽게 회원 가입이 가능하며 Repository를 연결하여 쉽게 

Build결과 또는 TEST 결과를 확인할 수 있다.

