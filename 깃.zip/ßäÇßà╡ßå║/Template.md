# 깃허브 PR TEMPLATE

협업을 하다보면 양식이 중구난방이여서 혼란이 많을 때가 많습니다.

작은 스타트업이라면 구두전달식으로는 이러한 양식을 통일 시킬수가 없습니다.

깃허브에는 **default branch**에 Template를 만들어 놓으면 Pull Request시 **자동으로 등록된 템플릿**을 양식으로 PR 문서를 작성할 수 있도록합니다.



### 작성하는법

폴더 또는 파일이 `root` 경로안에 위치 해야합니다.

- root
- docs/
- .github/

위의 경로에서 파일의 이름을 `PULL_REQUEST_TEMPLATE.md` 로 만들어 줍니다.



### 적용

먼저 프로젝트 경로로 이동합니다.

```bash
$ cd ../project
```

.github 폴더를 생성합니다.

```bash
$ mkdir .github
```

vi 를 사용하여 **PR 템플릿**파일을 작성합니다.

```bash
$ cd .github
$ vi PULL_REQUEST_TEMPLATE.md
```

vi 를 사용하여 **이슈 템플릿**파일을 작성할 수도 있습니다.

```
$ cd .github
$ vi ISSUE_TEMPLATE.md
```



### 예시 템플릿

```bash
## 개요
여기에 기능에 대한 간략한 설명을 적어주세요.

## 작업사항
- 여기에 기능에 대한 작업 사항을 적어주세요
- N/A

## 기타사항
- N/A
```



### 참조 : [TEMPLATE](https://axolo.co/blog/p/part-3-github-pull-request-template)

