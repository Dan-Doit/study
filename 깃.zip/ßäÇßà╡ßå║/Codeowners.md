# 깃허브 CODEOWNERS

깃허브에서 Pull Request를 올릴때 항상 하는 작업들이 있습니다.

그 중에서 리뷰어를 매번 등록하는것은 너무나 번거로운 작업이 아닐수 없습니다.

그래서 깃에서는 리뷰어 자동 등록을 설정에 따라 바꿀수 있습니다.



### 작성하는법

폴더가 `root` 경로안에 위치 해야합니다.

- .github/

위의 경로에서 파일의 이름을 `CODEOWNERS` 로 만들어 줍니다 (확장자는 없습니다).



### 적용

먼저 프로젝트 경로로 이동합니다.

```bash
$ cd ../project
```

.github 폴더를 생성합니다.

```bash
$ mkdir .github
```

vi 를 사용하여 md파일을 작성합니다.

```bash
$ cd .github
$ vi CODEOWNERS
```



### 예시 템플릿

```bash
# 모든 코드에 대한 리뷰어
* @Dan-Doit @owner1 @owner2

# js 파일에 대한 리뷰어
*.js @Dan-Doit @owner1 @owner2

# go파일에 대한 리뷰어 email로 추가하기
*.go docs@example.com

# apps 경로에 대한 리뷰어
# /apps/.github 경로에는 리뷰어 없음
/apps/ @owner1
/apps/.github 
```



### 참조 : [CODEOWNERS](https://goodgid.github.io/Github-CODEOWNERS/)