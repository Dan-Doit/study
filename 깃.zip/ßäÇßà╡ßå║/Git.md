## 깃 ID, PASS 없애는법

```shell
$ git config credential.helper store
$ git push https://github.com/repo.git		# 본인의 repository

Username for 'https://github.com': <USERNANE>
Password for 'https://USERNAME@github.com': <PASSWORD>
```



## 현재 Persnal Token

```shell
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
```

